<?php

namespace User\NewsWebsite;

class Validations
{
    private static $sources= ['google-news', 'usa-today', 'abc-news', 'cnn', 'business-insider'];
    private static $languages= ['ar', 'de', 'en', 'es', 'fr', 'he', 'it', 'nl', 'no', 'pt', 'ru', 'sv', 'ud', 'zh'];

    public static function dateVal($date) {
        $format= 'Y-m-d';
        $formattedDate= \DateTime::createFromFormat($format, $date);
        return $formattedDate && $formattedDate->format($format) === $date;
    }

    public static function sourcesVal($source) {
        if(in_array($source, Validations::$sources)) {
            return true;
        }
        return false;
    }

    public static function languageVal($language) {
        if(in_array($language, Validations::$languages)) {
            return true;
        }
        return false;
    }
}
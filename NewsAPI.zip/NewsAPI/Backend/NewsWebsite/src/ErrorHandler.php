<?php

namespace User\NewsWebsite;

class ErrorHandler extends \Exception
{
    public function handleError() {
        http_response_code(500);
        return $this->getMessage();
    }
}
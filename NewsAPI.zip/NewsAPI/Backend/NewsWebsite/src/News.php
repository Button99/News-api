<?php

namespace User\NewsWebsite;

class News
{
    public function __construct() { }
    public function getEverything($q, $from, $source, $language) {
        // news api url
        $url= 'https://newsapi.org/v2/everything?';
        // check if q is empty
        if(!is_null($q) || !empty($q)) {
            $url .= 'q=' . $q;
        } else {
            throw new ErrorHandler('Text input is required! ');
        }
        // check if date is valid
        if((!is_null($from) || !empty($from)) && Validations::dateVal($from)) {
            $url .= '&from=' . $from;
        }
        // check if source is valid
        if((!is_null($source) || !empty($source)) && Validations::sourcesVal($source) ) {
            $url .= '&sources=' . $source;
        }
        // check if language is valid
        if((!is_null($language) || !empty($language)) && Validations::languageVal($language)) {
            $url .= '&language=' . $language;
        }
        $url .= '&apiKey=125acb857ff44e29a73b4d249c88c1c2';
        // Request data from newsapi and return the response to Frontend
        try {
            $curl= curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_USERAGENT => 'Mozilla/5.0',
                CURLOPT_HEADER => 0
            ));
            $res= curl_exec($curl);
            curl_close($curl);
            return $res;
        } catch (\Exception $e) {
            throw new ErrorHandler($e->getMessage());
        }
    }
}
<script setup>
  import Card from "./Card.vue";
  import { ref, computed } from "vue";
  import axios from 'axios';

  // Number of articles per page, currentPage no. , articles, and the date
  const pageSize = 25; 
  const currentPage = ref(1);
  const articles = ref([]);
  const selectedDate= ref('');
  // query, selected language, selected source
  const q= ref('');
  const selectedLang = ref('');
  const selectedSource= ref('');

  // Get the total number of pages
  const totalPages = computed(() => {
    return Math.ceil(articles.value.length / pageSize);
  });

  // Get the articles for the current page
  const getPage = (page) => {
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return articles.value.slice(startIndex, endIndex);
  };

  // Create an array of page numbers to display navigation buttons
  const pages = computed(() => {
    const pages = [];
    for (let i = 1; i <= totalPages.value; i++) {
      pages.push(i);
    }
    return pages;
  });

  // when user presses the submit button the request is sent
  const submitForm= () => {
    if(q.value === null || q.value === '') {
      alert('Text field is required');
      return;
    }
    const formData= {
      query: q.value,
      language: selectedLang.value,
      date: selectedDate.value,
      source: selectedSource.value
    }

    // Fetch articles from BE
    axios.get("http://127.0.0.1:8000/src/index.php", {'params': formData})
      .then((res) => {
        articles.value = res.data.articles;
      })
      .catch((err) => {
        alert(err);
      });

  }

  // Language options
  const langOpt = [
        { value: 'ar', label: 'ar' },
        { value: 'de', label: 'de' },
        { value: 'en', label: 'en' },
        { value: 'es', label: 'es' },
        { value: 'fr', label: 'fr' },
        { value: 'he', label: 'he' },
        { value: 'it', label: 'it' },
        { value: 'nl', label: 'nl' },
        { value: 'no', label: 'no' },
        { value: 'pt', label: 'pt' },
        { value: 'ru', label: 'ru' },
        { value: 'sv', label: 'sv' },
        { value: 'ud', label: 'ud' },
        { value: 'zh', label: 'zh' },
    ];

    // Source Options
  const sourceOpt = [
      { value: 'google-news', label: 'Google News' },
      { value: 'usa-today', label: 'USA Today' },
      { value: 'abc-news', label: 'ABC News' },
      { value: 'cnn', label: 'CNN' },
      { value: 'business-insider', label: 'Business Insider' },
    ];

</script>
<template>
    <div class="header-wrapper p-3 md:py-5 bg-white border-b border-grey-light">
      <div class="header container w-none	 mx-auto flex items-center">
        <div class="logo font-bold text-2xl text-dark">NewsAPI</div>
          <div class="search flex-5 ml-10 mr-10 ">
            <input class="text-grey-dark font-light py-2 bg-grey-lighter px-5 border border-grey-light rounded" placeholder="Search..." type="text" v-model="q"/>
          </div>
          <div class="menu font-light inline-flex ">
            <form @submit.prevent="submitForm">
              <ul class="inline-flex"><li class="inline-flex"> <p class="py-2 mr-2">Language: </p>
                      <select class="bg-white-50 border border-white-300 text-dark-900 text-sm focus:ring-white-500 focus:border-white-500 block w-full p-2.5 dark:bg-dark-700 dark:border-dark-600 dark:placeholder-dark-400 dark:text-dark dark:focus:ring-white-500 dark:focus:border-white-500" v-model="selectedLang">
                        <option class="selected" value="">Choose a Language</option>
                        <option v-for="lang in langOpt" :value="lang.value">{{lang.label}}</option>
                      </select></li>
                      <li class="inline-flex ml-2"><p class="py-2 mr-2 ml-4">Date:</p> 
                        <input type="date" v-model="selectedDate"/>
                      </li>
                      <li class="inline-flex ml-2"><p class="py-2 mr-2">Source:</p> 
                        <select class="bg-white-50 border border-white-300 text-dark-900 text-sm focus:ring-white-500 focus:border-white-500 block w-full p-2.5 dark:bg-dark-700 dark:border-dark-600 dark:placeholder-dark-400 dark:text-dark dark:focus:ring-white-500 dark:focus:border-white-500" v-model="selectedSource">
                          <option class="selected" value="">Choose a Source</option>
                          <option v-for="source in sourceOpt" :value="source.value">{{source.label}}</option>
                        </select>
                      </li>
              </ul>
              <button class="bg-blue-100 font-bold py-2 px-4 rounded ml-2" type="submit">
                Search 
              </button>
            </form>
          </div>
        </div>
      </div>
      <div class="content-wrapper pt-8 flex-1 bg-grey-lighter">
        <div class="content py-4 container max-w-md mx-auto" >
          <card v-for="article in getPage(currentPage)" :key="article.id" :headline="article.title" :link="article.url" v-if="articles.length > 0">
            Author: {{ article.author }} <br/>
            Date of Publish: {{ article.publishedAt }}
          </card>
          <p v-else>Search for an article!</p>
        <div class="flex justify-center my-4">
          <button class="mx-2 border rounded-md py-1 px-2" :class="currentPage === 1 ? 'bg-gray-300 cursor-not-allowed' : 'bg-white'" :disabled="currentPage === 1" @click="currentPage--">
            Previous
          </button> {{ currentPage }} page
          <button class="mx-2 border rounded-md py-1 px-2" :class="currentPage === totalPages ? 'bg-gray-300 cursor-not-allowed' : 'bg-white'" :disabled="currentPage === totalPages" @click="currentPage++">
            Next
          </button>
        </div>
      </div>
    </div>
</template>

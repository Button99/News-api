<script setup>
defineProps({
  headline: String,
  link: String
});

</script>
<template>
    <div class="card md:rounded shadow bg-white p-8 mb-8">
      <a :href="link" target="_blank"><h1 class="text-2xl" v-html="headline"></h1></a>
      <p class="my-4 leading-normal"><slot/></p>
    </div>
  </template>
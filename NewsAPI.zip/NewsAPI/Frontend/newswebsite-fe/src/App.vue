<script setup>
import Content from './components/Content.vue'

</script>

<template>
  <Content></Content>
</template>
